<?php

get_header();

?>

<h1>page.php</h1>


<?php get_footer(); ?>