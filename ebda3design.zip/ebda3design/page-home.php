<?php
/* template name: Home */

get_header();
?>

<div>Template: Home</div>
<?php get_footer(); ?>
