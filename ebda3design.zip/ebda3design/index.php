<?php

// index.php


get_header();

?>
<h1>index.php</h1>
<?php

get_footer();   
