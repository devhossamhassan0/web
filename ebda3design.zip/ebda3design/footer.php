<h2>Footer</h2>
<?php wp_footer(); ?>
</body>
</html>